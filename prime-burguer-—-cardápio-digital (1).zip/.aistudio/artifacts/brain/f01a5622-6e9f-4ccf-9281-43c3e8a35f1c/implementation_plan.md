# Prime Burguer — Cardápio Digital de Alta Conversão

Aplicação web mobile-first e responsiva para o cardápio digital da hamburgueria **Prime Burguer** (*Projeto NH3 • Esquina da Rua 06 | Quarta a Segunda, das 18h às 23h*), com montagem interativa de hambúrgueres, personalização de bebidas, carrinho persistente com checkout direto para o WhatsApp e um assistente flutuante discreto equipado com chat multimodal, leitura em áudio (TTS) e pré-visualização visual de lanches por IA.

---

## Revisão do Usuário e Decisões Críticas

> [!IMPORTANT]
> As preferências confirmadas na etapa de esclarecimento foram incorporadas integralmente abaixo e guiam o comportamento do carrinho, checkout e interface.

- **Taxa de Entrega (Confirmada)**: Quando o cliente selecionar *Entrega* no checkout, exibir o aviso transparente *"Taxa de entrega a combinar no WhatsApp"* e incluir essa observação na mensagem final do pedido.
- **Mini Pudim de Sobremesa (Confirmado)**: Permitir adicionar o item normalmente ao carrinho com o rótulo **"A consultar"**, exibindo o subtotal dos demais itens somado à indicação de itens a consultar (sem travar o cálculo total).
- **Sabores de Refrigerante (Confirmado)**: Tanto o *Refrigerante Lata* quanto todos os *Combos* que acompanham refrigerante (Lata ou 1L) abrirão um seletor rápido de sabor (**Coca-Cola**, **Guaraná**, **Fanta**) antes da adição ao carrinho.
- **Layout Compacto & Assistente Discreto (Confirmado)**: O cardápio principal prioriza leitura rápida e cards compactos em fundo escuro (`#121212`) e grafite (`#1E1E1E`), mantendo o assistente de IA (chat, áudio TTS e geração de foto do lanche) acessível por meio de um botão flutuante discreto e sob demanda.
- **Chave de API Paga para Geração de Imagens**: O recurso opcional *"Visualizar Lanche"* utiliza o modelo `gemini-3-pro-image-preview` (com seletor de resolução `1K`, `2K` e `4K`). Antes de ativar essa chamada de imagem de alta resolução durante a construção, será exibido o fluxo de seleção de chave de API paga para habilitação da cota correspondente.

---

## 1. Visão Geral e Conceito

- **O Que Entrega**: Um cardápio digital rápido, sem fricção e otimizado para pedidos pelo celular no toque do polegar, mantendo expansão responsiva elegante em tablets e desktops.
- **Público-Alvo**: Clientes locais da Prime Burguer acessando via link do Instagram ou WhatsApp em smartphones, buscando escolher lanches, montar seu próprio hambúrguer ou pedir combos em poucos segundos.
- **Diferencial de Conversão**: Zero cadastro obrigatório, feedback imediato de quantidade e valor em tempo real, personalização guiada de sucos e refrigerantes e envio da comanda formatada diretamente para o WhatsApp da loja (`+55 74 8141-4076`).

---

## 2. Experiência do Usuário e Design Visual

### Fluxos Principais do Cliente

1. **Chegada e Navegação Rápida**: O cliente visualiza o cabeçalho com o logotipo oficial da Prime Burguer (enquadrado em recorte circular limpo), endereço (*Projeto NH3 • Esquina da Rua 06*) e horário (*Quarta a Segunda, 18h às 23h*). Logo abaixo, uma barra fixa de navegação horizontal permite saltar suavemente para **Hambúrgueres**, **Combos**, **Monte seu Burguer**, **Porções** e **Bebidas**.
2. **Adição Direta e Controle de Quantidade**: Cada item das categorias *Hambúrgueres* (com aviso destacado de que todos acompanham molho verde) e *Porções* possui o botão `+ Adicionar` em laranja vibrante (`#FFA000`), que se transforma em um seletor `− / Qtd / +` após adicionado (além de suportar o *Mini Pudim de Sobremesa* como `"A consultar"`).
3. **Personalização de Combos, Sucos e Refrigerantes**:
   - Ao adicionar *Suco 500 ml* (`R$ 8,00`) ou *Suco 1L* (`R$ 14,00`), abre-se um painel inferior (*bottom sheet*) para escolher o sabor (**Maracujá**, **Acerola**, **Goiaba**, **Cacau**, **Cupuaçu**) e marcar opcionalmente **Com leite (+R$ 3,00)**, recalculando o preço unitário na hora.
   - Ao adicionar *Refrigerante Lata* ou qualquer *Combo* (`Combo 01` a `Combo 07`), abre-se um painel rápido para escolher o sabor do(s) refrigerante(s) (**Coca-Cola**, **Guaraná**, **Fanta**).
4. **Construtor Interativo "Monte seu Burguer"**: Lista organizada de todos os 19 adicionais com seleção interativa e cálculo do valor total do lanche personalizado atualizado em tempo real conforme o cliente marca ou desmarca ingredientes, além de botão para adicionar o lanche montado ao carrinho (e atalho opcional para gerar uma prévia visual do lanche criado).
5. **Barra Inferior Fixa e Checkout WhatsApp**: Uma barra compacta fixa na base da tela exibe a quantidade total de itens e o valor acumulado. Ao tocar para avançar, abre-se o carrinho revisável com formulário simples de Checkout:
   - **Nome do cliente**
   - **Tipo de Entrega**: *Retirada no local* ou *Entrega* (exibindo campo de *Endereço* e aviso de *Taxa de entrega a combinar no WhatsApp*)
   - **Forma de Pagamento**: *Pix*, *Cartão* ou *Dinheiro* (exibindo campo *Troco para quanto?*)
   - **Botão "Finalizar Pedido no WhatsApp"**: Gera a mensagem completa, organizada por tópicos, e abre o link `https://wa.me/557481414076?text=...`.
6. **Assistente Flutuante Discreto (IA)**: Um botão discreto no canto inferior direito abre uma gaveta com três abas integradas:
   - **Atendente Chat**: Chat multi-turno que recomenda combinações do cardápio, tira dúvidas sobre ingredientes e responde no tom acolhedor da Prime Burguer.
   - **Ouvir Cardápio / Resumo (TTS)**: Botão para narrar em voz natural o resumo do pedido atual ou sugestões do dia.
   - **Visualizar Lanche (Imagem IA)**: Gerador sob demanda onde o usuário escolhe um lanche (ou usa seu lanche montado) e a resolução desejada (**1K**, **2K** ou **4K**) para visualizar uma foto realista do burger.

### Identidade Visual e Tema

- **Direção Estética**: Hamburgueria artesanal noturna (*dark editorial fast-casual*), leitura de alto contraste sob luz externa/celular e foco máximo em legibilidade e ação rápida.
- **Paleta de Cores (Disciplina 60-30-10)**:
  - *Fundo Dominante (60%)*: `#121212` (preto carvão profundo)
  - *Superfícies Estruturais (30%)*: `#1E1E1E` (cinza grafite para cartões e folhas de checkout) com divisores sutis `rgba(255,255,255,0.08)` e textos `#FFFFFF` / `#B3B3B3`
  - *Acento de Ação (10%)*: `#FFA000` (laranja vibrante da marca) exclusivamente em botões principais, seletores ativos e destaques de preço, sempre com texto preto em negrito (`#000000`) para contraste máximo.
- **Tipografia e Hierarquia**:
  - *Display / Títulos*: `Barlow Condensed` (peso condensado marcante em sintonia com o logotipo *PRIME BURGER*).
  - *Corpo / Descrições*: `Plus Jakarta Sans` (leitura limpa em tamanhos compactos no mobile, com `tabular-nums` em todos os preços `R$ XX,XX`).
- **Ergonomia Mobile & Limite de Sobreposição**: Alvos táteis mínimos de `44×44px` em todos os botões `+`/`−` e abas; cabeçalho enxuto e barra inferior de carrinho compacta respeitando o teto de ≤ 15% da altura útil da tela do celular; cards limpos sem poluição de badges ou bordas laterais grossas.

---

## 3. Decisões de Produto e Trade-offs

- **Cards Compactos de Alta Densidade**:
  - *Abordagem Escolhida*: Cards horizontais enxutos com nome, descrição objetiva, preço alinhado à direita e controle `+ Adicionar` imediato, sem imagens pesadas repetitivas ocupando a tela inteira.
  - *Por quê*: Atende à preferência por cardápio compacto de alta conversão e permite ao cliente percorrer todos os 7 hambúrgueres e 7 combos rapidamente com uma mão.
  - *Alternativa Descartada*: Cards verticais gigantes com fotos grandes por item, que dobrariam a rolagem no celular.
- **Estado do Carrinho Local + Backend Express para IA**:
  - *Abordagem Escolhida*: Carrinho e estado do pedido gerenciados no cliente (com persistência em `localStorage` para não perder o pedido ao alternar abas), enquanto todas as chamadas ao SDK `@google/genai` (Chat, TTS e Geração de Imagem) rodam exclusivamente em rotas de servidor Express.
  - *Por quê*: Garante carregamento instantâneo do cardápio e do checkout mesmo em conexões móveis instáveis, mantendo as credenciais e chamadas de IA protegidas no servidor.

---

## 4. Arquitetura Técnica e Estratégia de Dados

### Diagrama de Arquitetura e Fluxo de Estado

```text
┌──────────────────────────────────────────────────────────────────────┐
│                        Cliente Web (React SPA)                       │
│                                                                      │
│  ┌────────────────┐   ┌──────────────────┐   ┌────────────────────┐  │
│  │ Navegação Topo │   │ Catálogo Compacto│   │  Monte seu Burguer │  │
│  │  (5 Categorias)│──▶│ Burgers / Combos │   │ (19 Adicionais em  │  │
│  └────────────────┘   │ Porções / Bebidas│   │     Tempo Real)    │  │
│                       └────────┬─────────┘   └─────────┬──────────┘  │
│                                │                       │             │
│                                ▼                       ▼             │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │   Modais de Personalização (Bottom Sheets Mobile-First)        │  │
│  │   • Sucos: Sabor + Adicional de Leite (+R$ 3,00)               │  │
│  │   • Refrigerantes & Combos: Seleção de Sabor (Coca/Guaraná/Fanta)│
│  └─────────────────────────────┬──────────────────────────────────┘  │
│                                │                                     │
│                                ▼                                     │
│  ┌──────────────────────┐    ┌────────────────────────────────────┐  │
│  │  Store do Carrinho   │───▶│ Barra Fixa + Drawer de Checkout    │  │
│  │ (Itens + "A consultar│    │ Nome, Retirada/Entrega, Pagamento  │  │
│  │  + Persistência)     │    │ ──▶ Link WhatsApp (wa.me/5574...)  │  │
│  └──────────────────────┘    └────────────────────────────────────┘  │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │ Assistente Flutuante Discreto                                  │  │
│  │ [Chat Atendente]  [Ouvir Resumo (TTS)]  [Gerar Foto 1K/2K/4K]  │  │
│  └────────┬──────────────────┬───────────────────────┬────────────┘  │
└───────────┼──────────────────┼───────────────────────┼───────────────┘
            │ POST /api/chat   │ POST /api/tts         │ POST /api/image
            ▼                  ▼                       ▼
┌──────────────────────────────────────────────────────────────────────┐
│                  Servidor Express (Backend Integrado)                │
│                                                                      │
│  • Chat Multi-Turno ──▶ @google/genai (gemini-4-hydrogen)            │
│  • Narração em Áudio ──▶ @google/genai (gemini-3.8-flash-tts, WAV)   │
│  • Foto do Lanche ─────▶ @google/genai (gemini-3-pro-image-preview)  │
└──────────────────────────────────────────────────────────────────────┘
```

### Modelo de Dados e Mapeamento Interativo

- **Catálogo Estruturado**: Tipagem rigorosa separando `Hambúrgueres` (com nota global de molho verde), `Combos` (com metadados de quantos refrigerantes lata ou 1L acompanham para disparo do seletor de sabor), `Adicionais` (19 itens do *Monte seu Burguer*), `Porções & Sobremesa` (incluindo flag `priceOnRequest` para o *Mini Pudim*) e `Bebidas` (incluindo regras de personalização para *Suco 500 ml*, *Suco 1L* e *Refrigerante Lata*).
- **Itens no Carrinho**: Cada linha do carrinho armazena uma chave única composta pelo ID do item + assinatura das escolhas (sabor do suco, com/sem leite, sabores de refrigerante ou lista de ingredientes do burguer personalizado), permitindo agrupar itens idênticos e incrementar/decrementar quantidades com precisão.
- **Serviços de IA no Servidor**:
  - `/api/chat`: Recebe o histórico de mensagens e contexto do cardápio/carrinho atual, mantendo conversa contínua via `ai.chats` com instrução de sistema dedicada à Prime Burguer.
  - `/api/tts`: Converte textos do cardápio ou o resumo do pedido em áudio WAV (`audio/wav`) usando `gemini-3.8-flash-tts` para reprodução direta no navegador.
  - `/api/generate-image`: Gera prévia fotográfica do lanche escolhido ou personalizado via `gemini-3-pro-image-preview` respeitando o parâmetro `imageSize` (`"1K"`, `"2K"` ou `"4K"`) selecionado pelo usuário.
