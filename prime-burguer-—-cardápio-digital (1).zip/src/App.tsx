import { useEffect, useMemo, useRef, useState } from "react";
import { AttendantButton } from "./components/AttendantButton";
import { CartBar } from "./components/CartBar";
import { CategoryNav } from "./components/CategoryNav";
import { CheckoutDrawer } from "./components/CheckoutDrawer";
import { CustomBurgerBuilder } from "./components/CustomBurgerBuilder";
import { Header } from "./components/Header";
import { MenuItemCard } from "./components/MenuItemCard";
import { OptionModal } from "./components/OptionModal";
import { MENU_ITEMS, STORE_INFO, formatCurrency } from "./data/menu";
import { CartItem, CategoryId, CheckoutInfo, MenuItem } from "./types";

const CART_STORAGE_KEY = "prime-burguer-cart-v1";
const CHECKOUT_STORAGE_KEY = "prime-burguer-checkout-v1";

const DEFAULT_CHECKOUT: CheckoutInfo = {
  customerName: "",
  deliveryType: "retirada",
  address: "",
  paymentMethod: "Pix",
  changeFor: "",
  notes: "",
};

export default function App() {
  const [activeCategory, setActiveCategory] =
    useState<CategoryId>("hamburgueres");

  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      return saved ? (JSON.parse(saved) as CartItem[]) : [];
    } catch {
      return [];
    }
  });

  const [checkout, setCheckout] = useState<CheckoutInfo>(() => {
    try {
      const saved = localStorage.getItem(CHECKOUT_STORAGE_KEY);
      return saved
        ? { ...DEFAULT_CHECKOUT, ...(JSON.parse(saved) as Partial<CheckoutInfo>) }
        : DEFAULT_CHECKOUT;
    } catch {
      return DEFAULT_CHECKOUT;
    }
  });

  const [pendingOptionItem, setPendingOptionItem] = useState<MenuItem | null>(
    null
  );
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);

  const sectionRefs = useRef<Record<CategoryId, HTMLElement | null>>({
    hamburgueres: null,
    combos: null,
    "monte-seu-burguer": null,
    porcoes: null,
    bebidas: null,
  });

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(CHECKOUT_STORAGE_KEY, JSON.stringify(checkout));
    } catch {
      // ignore storage quota errors
    }
  }, [checkout]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveCategory(entry.target.id as CategoryId);
          }
        }
      },
      {
        rootMargin: "-90px 0px -65% 0px",
        threshold: 0,
      }
    );

    const elements = Object.values(sectionRefs.current);
    elements.forEach((el) => {
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  const handleSelectCategory = (category: CategoryId) => {
    setActiveCategory(category);
    const target = sectionRefs.current[category];
    if (target) {
      target.scrollIntoView({ behavior: "smooth", block: "start" });
    }
  };

  const getItemQuantity = (itemId: string): number => {
    return cart
      .filter((entry) => entry.itemId === itemId)
      .reduce((sum, entry) => sum + entry.quantity, 0);
  };

  const addSimpleItem = (item: MenuItem) => {
    if (item.customizationType) {
      setPendingOptionItem(item);
      return;
    }

    const cartKey = item.id;
    setCart((prev) => {
      const existing = prev.find((c) => c.cartKey === cartKey);
      if (existing) {
        return prev.map((c) =>
          c.cartKey === cartKey ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [
        ...prev,
        {
          cartKey,
          itemId: item.id,
          name: item.name,
          unitPrice: item.price,
          priceOnRequest: item.priceOnRequest,
          quantity: 1,
        },
      ];
    });
  };

  const decrementSimpleItem = (item: MenuItem) => {
    const cartKey = item.id;
    setCart((prev) =>
      prev
        .map((c) =>
          c.cartKey === cartKey ? { ...c, quantity: c.quantity - 1 } : c
        )
        .filter((c) => c.quantity > 0)
    );
  };

  const handleConfirmOption = (
    item: MenuItem,
    details: string[],
    finalUnitPrice: number,
    variantKey: string
  ) => {
    const cartKey = `${item.id}::${variantKey}`;
    setCart((prev) => {
      const existing = prev.find((c) => c.cartKey === cartKey);
      if (existing) {
        return prev.map((c) =>
          c.cartKey === cartKey ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [
        ...prev,
        {
          cartKey,
          itemId: item.id,
          name: item.name,
          unitPrice: finalUnitPrice,
          quantity: 1,
          details,
        },
      ];
    });
    setPendingOptionItem(null);
  };

  const handleAddCustomBurger = (
    ingredients: Array<{ name: string; price: number; quantity: number }>,
    totalPrice: number
  ) => {
    const signature = ingredients
      .map((i) => `${i.quantity}x${i.name}`)
      .sort()
      .join("|");
    const cartKey = `custom-burger::${signature}`;
    const details = ingredients.map((i) =>
      i.quantity > 1
        ? `${i.quantity}x ${i.name} (${formatCurrency(i.price * i.quantity)})`
        : `${i.name} (${formatCurrency(i.price)})`
    );

    setCart((prev) => {
      const existing = prev.find((c) => c.cartKey === cartKey);
      if (existing) {
        return prev.map((c) =>
          c.cartKey === cartKey ? { ...c, quantity: c.quantity + 1 } : c
        );
      }
      return [
        ...prev,
        {
          cartKey,
          itemId: "custom-burger",
          name: "Burguer Personalizado",
          unitPrice: totalPrice,
          quantity: 1,
          details,
        },
      ];
    });
  };

  const handleUpdateCartQuantity = (cartKey: string, delta: number) => {
    setCart((prev) =>
      prev
        .map((c) =>
          c.cartKey === cartKey ? { ...c, quantity: c.quantity + delta } : c
        )
        .filter((c) => c.quantity > 0)
    );
  };

  const handleRemoveCartItem = (cartKey: string) => {
    setCart((prev) => prev.filter((c) => c.cartKey !== cartKey));
  };

  const { totalItems, numericTotal, hasPriceOnRequest } = useMemo(() => {
    let count = 0;
    let total = 0;
    let onRequest = false;

    for (const item of cart) {
      count += item.quantity;
      if (item.priceOnRequest || item.unitPrice === null) {
        onRequest = true;
      } else {
        total += item.unitPrice * item.quantity;
      }
    }

    return {
      totalItems: count,
      numericTotal: total,
      hasPriceOnRequest: onRequest,
    };
  }, [cart]);

  const burgers = MENU_ITEMS.filter((i) => i.category === "hamburgueres");
  const combos = MENU_ITEMS.filter((i) => i.category === "combos");
  const portions = MENU_ITEMS.filter((i) => i.category === "porcoes");
  const drinks = MENU_ITEMS.filter((i) => i.category === "bebidas");

  return (
    <div className="min-h-screen bg-[#121212] text-white">
      <Header />
      <CategoryNav
        activeCategory={activeCategory}
        onSelectCategory={handleSelectCategory}
      />

      <main
        className={`mx-auto max-w-6xl space-y-10 px-4 pt-6 sm:px-6 ${
          totalItems > 0 ? "pb-28" : "pb-16"
        }`}
      >
        {/* 1. Hambúrgueres */}
        <section
          id="hamburgueres"
          ref={(el) => {
            sectionRefs.current.hamburgueres = el;
          }}
          className="scroll-mt-16"
        >
          <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Hambúrgueres
            </h2>
            <p className="text-xs font-medium text-[#FFA000] sm:text-sm">
              Todos acompanham molho verde
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {burgers.map((item) => (
              <MenuItemCard
                key={item.id}
                item={item}
                quantityInCart={getItemQuantity(item.id)}
                onAdd={addSimpleItem}
                onIncrement={addSimpleItem}
                onDecrement={decrementSimpleItem}
              />
            ))}
          </div>
        </section>

        {/* 2. Combos */}
        <section
          id="combos"
          ref={(el) => {
            sectionRefs.current.combos = el;
          }}
          className="scroll-mt-16"
        >
          <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Combos
            </h2>
            <p className="text-xs text-neutral-400 sm:text-sm">
              Escolha o sabor do refrigerante ao adicionar
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {combos.map((item) => (
              <MenuItemCard
                key={item.id}
                item={item}
                quantityInCart={getItemQuantity(item.id)}
                onAdd={addSimpleItem}
              />
            ))}
          </div>
        </section>

        {/* 3. Monte seu Burguer */}
        <section
          id="monte-seu-burguer"
          ref={(el) => {
            sectionRefs.current["monte-seu-burguer"] = el;
          }}
          className="scroll-mt-16"
        >
          <div className="mb-4">
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Monte seu Burguer
            </h2>
          </div>

          <CustomBurgerBuilder
            onAddCustomBurger={handleAddCustomBurger}
          />
        </section>

        {/* 4. Porções & Sobremesa */}
        <section
          id="porcoes"
          ref={(el) => {
            sectionRefs.current.porcoes = el;
          }}
          className="scroll-mt-16"
        >
          <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Porções &amp; Sobremesa
            </h2>
            <p className="text-xs text-neutral-400 sm:text-sm">
              Acompanhamentos crocantes e mini pudim
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {portions.map((item) => (
              <MenuItemCard
                key={item.id}
                item={item}
                quantityInCart={getItemQuantity(item.id)}
                onAdd={addSimpleItem}
                onIncrement={addSimpleItem}
                onDecrement={decrementSimpleItem}
              />
            ))}
          </div>
        </section>

        {/* 5. Bebidas */}
        <section
          id="bebidas"
          ref={(el) => {
            sectionRefs.current.bebidas = el;
          }}
          className="scroll-mt-16"
        >
          <div className="mb-4 flex flex-col gap-1 sm:flex-row sm:items-baseline sm:justify-between">
            <h2 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Bebidas
            </h2>
            <p className="text-xs text-neutral-400 sm:text-sm">
              Sucos de Maracujá, Acerola, Goiaba, Cacau ou Cupuaçu
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3 md:grid-cols-2">
            {drinks.map((item) => (
              <MenuItemCard
                key={item.id}
                item={item}
                quantityInCart={getItemQuantity(item.id)}
                onAdd={addSimpleItem}
                onIncrement={addSimpleItem}
                onDecrement={decrementSimpleItem}
              />
            ))}
          </div>
        </section>
      </main>

      <footer
        className={`border-t border-white/10 bg-[#121212] px-4 py-6 text-center text-xs text-neutral-400 ${
          totalItems > 0 ? "pb-24" : "pb-10"
        }`}
      >
        <p className="font-semibold text-neutral-200">{STORE_INFO.name}</p>
        <p className="mt-1">
          {STORE_INFO.location} · {STORE_INFO.hours}
        </p>
      </footer>

      {pendingOptionItem && (
        <OptionModal
          item={pendingOptionItem}
          onClose={() => setPendingOptionItem(null)}
          onConfirm={handleConfirmOption}
        />
      )}

      <CartBar
        totalItems={totalItems}
        numericTotal={numericTotal}
        hasPriceOnRequest={hasPriceOnRequest}
        onOpenCheckout={() => setIsCheckoutOpen(true)}
      />

      <CheckoutDrawer
        isOpen={isCheckoutOpen}
        items={cart}
        checkout={checkout}
        onChangeCheckout={setCheckout}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onClearCart={() => setCart([])}
        onClose={() => setIsCheckoutOpen(false)}
      />

      <AttendantButton hasCartItems={totalItems > 0} />
    </div>
  );
}
