import { MessageSquare } from "lucide-react";
import { STORE_INFO } from "../data/menu";

interface AttendantButtonProps {
  hasCartItems: boolean;
}

export function AttendantButton({ hasCartItems }: AttendantButtonProps) {
  const attendantUrl = `https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(
    "Olá! Gostaria de falar com um atendente da Prime Burguer."
  )}`;

  return (
    <a
      href={attendantUrl}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar com atendente no WhatsApp"
      className={`fixed right-3 z-30 inline-flex min-h-[44px] items-center gap-2 rounded-full border border-[#FFA000]/40 bg-[#1E1E1E]/95 px-3.5 py-2 text-xs font-semibold text-white shadow-lg backdrop-blur-md transition-all hover:border-[#FFA000] hover:bg-[#252525] active:scale-95 sm:right-6 ${
        hasCartItems ? "bottom-[74px]" : "bottom-4"
      }`}
    >
      <MessageSquare className="h-4 w-4 text-[#FFA000]" aria-hidden="true" />
      <span>Atendente</span>
    </a>
  );
}
