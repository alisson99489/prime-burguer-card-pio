import { ShoppingBag } from "lucide-react";
import { formatCurrency } from "../data/menu";

interface CartBarProps {
  totalItems: number;
  numericTotal: number;
  hasPriceOnRequest: boolean;
  onOpenCheckout: () => void;
}

export function CartBar({
  totalItems,
  numericTotal,
  hasPriceOnRequest,
  onOpenCheckout,
}: CartBarProps) {
  if (totalItems === 0) return null;

  return (
    <div className="fixed right-0 bottom-0 left-0 z-40 border-t border-white/10 bg-[#181818]/95 px-3 py-2 backdrop-blur-md sm:px-6">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-3">
        <div className="min-w-0">
          <div className="flex items-baseline gap-2">
            <span className="tabular-nums text-xs font-medium text-neutral-300 sm:text-sm">
              {totalItems} {totalItems === 1 ? "item" : "itens"}
            </span>
            <span className="text-neutral-600" aria-hidden="true">
              ·
            </span>
            <span className="tabular-nums text-base font-extrabold text-[#FFA000] sm:text-lg">
              {formatCurrency(numericTotal)}
            </span>
          </div>
          {hasPriceOnRequest && (
            <p className="truncate text-[11px] text-neutral-400">
              + item a consultar no WhatsApp
            </p>
          )}
        </div>

        <button
          type="button"
          onClick={onOpenCheckout}
          className="inline-flex min-h-[44px] shrink-0 items-center justify-center gap-2 rounded-lg bg-[#FFA000] px-4 py-2 text-sm font-bold text-black transition-transform hover:brightness-105 active:scale-[0.98] whitespace-nowrap sm:px-6"
        >
          <ShoppingBag className="h-4 w-4 stroke-[2.2]" aria-hidden="true" />
          <span>Ver Pedido</span>
        </button>
      </div>
    </div>
  );
}
