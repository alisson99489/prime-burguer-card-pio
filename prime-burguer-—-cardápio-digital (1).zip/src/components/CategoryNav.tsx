import { CATEGORY_TABS } from "../data/menu";
import { CategoryId } from "../types";

interface CategoryNavProps {
  activeCategory: CategoryId;
  onSelectCategory: (category: CategoryId) => void;
}

export function CategoryNav({
  activeCategory,
  onSelectCategory,
}: CategoryNavProps) {
  return (
    <nav
      aria-label="Categorias do cardápio"
      className="sticky top-0 z-30 border-b border-white/10 bg-[#121212]/95 backdrop-blur-md"
    >
      <div className="mx-auto max-w-6xl px-3 sm:px-6">
        <div className="no-scrollbar flex items-center gap-1.5 overflow-x-auto py-1.5">
          {CATEGORY_TABS.map((tab) => {
            const isActive = activeCategory === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onSelectCategory(tab.id)}
                className={`min-h-[40px] shrink-0 whitespace-nowrap rounded-lg px-3.5 py-2 text-xs font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#FFA000] sm:text-sm ${
                  isActive
                    ? "bg-[#FFA000] font-bold text-black"
                    : "bg-[#1E1E1E] text-neutral-300 hover:bg-neutral-800 hover:text-white"
                }`}
              >
                {tab.label}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
