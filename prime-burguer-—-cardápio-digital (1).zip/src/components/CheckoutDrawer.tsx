import { useMemo, useState } from "react";
import {
  AlertCircle,
  ExternalLink,
  Minus,
  Plus,
  ShoppingBag,
  Trash2,
  X,
} from "lucide-react";
import {
  buildWhatsAppUrl,
  formatCurrency,
} from "../data/menu";
import {
  CartItem,
  CheckoutInfo,
  DeliveryType,
  PaymentMethod,
} from "../types";

interface CheckoutDrawerProps {
  isOpen: boolean;
  items: CartItem[];
  checkout: CheckoutInfo;
  onChangeCheckout: (next: CheckoutInfo) => void;
  onUpdateQuantity: (cartKey: string, delta: number) => void;
  onRemoveItem: (cartKey: string) => void;
  onClearCart: () => void;
  onClose: () => void;
}

export function CheckoutDrawer({
  isOpen,
  items,
  checkout,
  onChangeCheckout,
  onUpdateQuantity,
  onRemoveItem,
  onClearCart,
  onClose,
}: CheckoutDrawerProps) {
  const [validationError, setValidationError] = useState<string | null>(null);

  const { numericSubtotal, hasPriceOnRequest } = useMemo(() => {
    let subtotal = 0;
    let onRequest = false;
    for (const item of items) {
      if (item.priceOnRequest || item.unitPrice === null) {
        onRequest = true;
      } else {
        subtotal += item.unitPrice * item.quantity;
      }
    }
    return { numericSubtotal: subtotal, hasPriceOnRequest: onRequest };
  }, [items]);

  if (!isOpen) return null;

  const isNameValid = checkout.customerName.trim().length >= 2;
  const isAddressValid =
    checkout.deliveryType === "retirada" ||
    checkout.address.trim().length >= 5;
  const isFormValid = items.length > 0 && isNameValid && isAddressValid;

  const whatsappUrl = isFormValid ? buildWhatsAppUrl(items, checkout) : "#";

  const handleCheckoutClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!isNameValid) {
      e.preventDefault();
      setValidationError("Informe seu nome para identificar o pedido.");
      return;
    }
    if (!isAddressValid) {
      e.preventDefault();
      setValidationError(
        "Informe o endereço completo para entrega (rua, número e referência)."
      );
      return;
    }
    setValidationError(null);
  };

  const setDelivery = (deliveryType: DeliveryType) => {
    setValidationError(null);
    onChangeCheckout({ ...checkout, deliveryType });
  };

  const setPayment = (paymentMethod: PaymentMethod) => {
    onChangeCheckout({ ...checkout, paymentMethod });
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-end bg-black/75 backdrop-blur-xs sm:items-stretch"
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-drawer-title"
    >
      <div className="flex max-h-[92dvh] w-full flex-col rounded-t-2xl border-t border-white/10 bg-[#121212] sm:h-full sm:max-h-none sm:max-w-lg sm:rounded-none sm:border-t-0 sm:border-l">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-white/10 bg-[#1E1E1E] px-4 py-3.5 sm:px-6">
          <div className="flex items-center gap-2.5">
            <ShoppingBag className="h-5 w-5 text-[#FFA000]" aria-hidden="true" />
            <h2
              id="checkout-drawer-title"
              className="font-display text-xl font-bold text-white"
            >
              Seu Pedido
            </h2>
          </div>

          <div className="flex items-center gap-1">
            {items.length > 0 && (
              <button
                type="button"
                onClick={onClearCart}
                className="min-h-[40px] rounded-lg px-2.5 text-xs font-medium text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white"
              >
                Limpar
              </button>
            )}
            <button
              type="button"
              onClick={onClose}
              aria-label="Fechar carrinho"
              className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white"
            >
              <X className="h-5 w-5" aria-hidden="true" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 space-y-5 overflow-y-auto px-4 py-4 sm:px-6">
          {items.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-12 text-center">
              <ShoppingBag
                className="h-10 w-10 text-neutral-600"
                aria-hidden="true"
              />
              <p className="mt-3 text-base font-semibold text-white">
                Seu carrinho está vazio
              </p>
              <p className="mt-1 text-sm text-neutral-400">
                Adicione hambúrgueres, combos ou monte seu lanche no cardápio.
              </p>
              <button
                type="button"
                onClick={onClose}
                className="mt-5 min-h-[44px] rounded-lg bg-[#FFA000] px-5 py-2.5 text-sm font-bold text-black"
              >
                Voltar ao Cardápio
              </button>
            </div>
          ) : (
            <>
              {/* Itens do Carrinho */}
              <div className="space-y-2.5">
                {items.map((item) => (
                  <div
                    key={item.cartKey}
                    className="rounded-xl border border-white/8 bg-[#1E1E1E] p-3.5"
                  >
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0 flex-1">
                        <h3 className="text-sm font-semibold text-white">
                          {item.name}
                        </h3>
                        {item.details && item.details.length > 0 && (
                          <ul className="mt-1 space-y-0.5 text-xs text-neutral-400">
                            {item.details.map((detail, idx) => (
                              <li key={idx}>• {detail}</li>
                            ))}
                          </ul>
                        )}
                      </div>

                      <div className="shrink-0 text-right">
                        {item.priceOnRequest || item.unitPrice === null ? (
                          <span className="text-xs font-semibold text-[#FFA000]">
                            A consultar
                          </span>
                        ) : (
                          <span className="tabular-nums text-sm font-bold text-[#FFA000]">
                            {formatCurrency(item.unitPrice * item.quantity)}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 flex items-center justify-between">
                      <button
                        type="button"
                        onClick={() => onRemoveItem(item.cartKey)}
                        className="inline-flex min-h-[36px] items-center gap-1 rounded-md px-2 text-xs text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-red-400"
                      >
                        <Trash2 className="h-3.5 w-3.5" aria-hidden="true" />
                        <span>Remover</span>
                      </button>

                      <div className="inline-flex items-center overflow-hidden rounded-lg border border-white/10 bg-[#121212]">
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartKey, -1)}
                          aria-label={`Diminuir quantidade de ${item.name}`}
                          className="flex min-h-[40px] min-w-[40px] items-center justify-center text-white hover:bg-neutral-800"
                        >
                          <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                        </button>
                        <span className="tabular-nums min-w-[2rem] text-center text-sm font-bold text-white">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() => onUpdateQuantity(item.cartKey, 1)}
                          aria-label={`Aumentar quantidade de ${item.name}`}
                          className="flex min-h-[40px] min-w-[40px] items-center justify-center bg-[#FFA000] text-black hover:brightness-105"
                        >
                          <Plus className="h-3.5 w-3.5 stroke-[2.5]" aria-hidden="true" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Formulário de Checkout */}
              <div className="space-y-4 rounded-xl border border-white/10 bg-[#1E1E1E] p-4">
                <h3 className="font-display text-lg font-bold text-white">
                  Dados para Finalizar
                </h3>

                <div>
                  <label
                    htmlFor="customer-name"
                    className="mb-1.5 block text-xs font-semibold text-neutral-300"
                  >
                    Seu Nome *
                  </label>
                  <input
                    id="customer-name"
                    type="text"
                    value={checkout.customerName}
                    onChange={(e) => {
                      setValidationError(null);
                      onChangeCheckout({
                        ...checkout,
                        customerName: e.target.value,
                      });
                    }}
                    placeholder="Ex: João Silva"
                    className="min-h-[44px] w-full rounded-lg border border-white/12 bg-[#121212] px-3.5 text-sm text-white placeholder:text-neutral-500 focus:border-[#FFA000] focus:outline-none"
                  />
                </div>

                <div>
                  <span className="mb-1.5 block text-xs font-semibold text-neutral-300">
                    Tipo de Entrega *
                  </span>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      type="button"
                      onClick={() => setDelivery("retirada")}
                      className={`min-h-[44px] rounded-lg border px-3 text-xs font-semibold transition-colors sm:text-sm ${
                        checkout.deliveryType === "retirada"
                          ? "border-[#FFA000] bg-[#FFA000] font-bold text-black"
                          : "border-white/10 bg-[#121212] text-neutral-300 hover:border-white/25"
                      }`}
                    >
                      Retirada no local
                    </button>
                    <button
                      type="button"
                      onClick={() => setDelivery("entrega")}
                      className={`min-h-[44px] rounded-lg border px-3 text-xs font-semibold transition-colors sm:text-sm ${
                        checkout.deliveryType === "entrega"
                          ? "border-[#FFA000] bg-[#FFA000] font-bold text-black"
                          : "border-white/10 bg-[#121212] text-neutral-300 hover:border-white/25"
                      }`}
                    >
                      Entrega
                    </button>
                  </div>
                </div>

                {checkout.deliveryType === "entrega" && (
                  <div className="space-y-2">
                    <div>
                      <label
                        htmlFor="delivery-address"
                        className="mb-1.5 block text-xs font-semibold text-neutral-300"
                      >
                        Endereço Completo *
                      </label>
                      <input
                        id="delivery-address"
                        type="text"
                        value={checkout.address}
                        onChange={(e) => {
                          setValidationError(null);
                          onChangeCheckout({
                            ...checkout,
                            address: e.target.value,
                          });
                        }}
                        placeholder="Rua, número, bairro / ponto de referência"
                        className="min-h-[44px] w-full rounded-lg border border-white/12 bg-[#121212] px-3.5 text-sm text-white placeholder:text-neutral-500 focus:border-[#FFA000] focus:outline-none"
                      />
                    </div>
                    <p className="text-xs font-medium text-[#FFA000]">
                      Taxa de entrega a combinar no WhatsApp.
                    </p>
                  </div>
                )}

                <div>
                  <span className="mb-1.5 block text-xs font-semibold text-neutral-300">
                    Forma de Pagamento *
                  </span>
                  <div className="grid grid-cols-3 gap-2">
                    {(["Pix", "Cartão", "Dinheiro"] as PaymentMethod[]).map(
                      (method) => (
                        <button
                          key={method}
                          type="button"
                          onClick={() => setPayment(method)}
                          className={`min-h-[44px] rounded-lg border px-2 text-xs font-semibold transition-colors sm:text-sm ${
                            checkout.paymentMethod === method
                              ? "border-[#FFA000] bg-[#FFA000] font-bold text-black"
                              : "border-white/10 bg-[#121212] text-neutral-300 hover:border-white/25"
                          }`}
                        >
                          {method}
                        </button>
                      )
                    )}
                  </div>
                </div>

                {checkout.paymentMethod === "Dinheiro" && (
                  <div>
                    <label
                      htmlFor="change-for"
                      className="mb-1.5 block text-xs font-semibold text-neutral-300"
                    >
                      Troco para quanto?
                    </label>
                    <input
                      id="change-for"
                      type="text"
                      value={checkout.changeFor}
                      onChange={(e) =>
                        onChangeCheckout({
                          ...checkout,
                          changeFor: e.target.value,
                        })
                      }
                      placeholder="Ex: R$ 50,00 (ou deixe em branco se não precisar)"
                      className="min-h-[44px] w-full rounded-lg border border-white/12 bg-[#121212] px-3.5 text-sm text-white placeholder:text-neutral-500 focus:border-[#FFA000] focus:outline-none"
                    />
                  </div>
                )}

                <div>
                  <label
                    htmlFor="order-notes"
                    className="mb-1.5 block text-xs font-semibold text-neutral-300"
                  >
                    Observações (opcional)
                  </label>
                  <input
                    id="order-notes"
                    type="text"
                    value={checkout.notes}
                    onChange={(e) =>
                      onChangeCheckout({ ...checkout, notes: e.target.value })
                    }
                    placeholder="Ex: tirar cebola, molho extra..."
                    className="min-h-[44px] w-full rounded-lg border border-white/12 bg-[#121212] px-3.5 text-sm text-white placeholder:text-neutral-500 focus:border-[#FFA000] focus:outline-none"
                  />
                </div>
              </div>
            </>
          )}
        </div>

        {/* Footer CTA */}
        {items.length > 0 && (
          <div className="border-t border-white/10 bg-[#1E1E1E] px-4 py-3.5 sm:px-6">
            {validationError && (
              <div className="mb-3 flex items-center gap-2 rounded-lg border border-red-500/40 bg-red-500/10 px-3 py-2 text-xs font-medium text-red-300">
                <AlertCircle className="h-4 w-4 shrink-0" aria-hidden="true" />
                <span>{validationError}</span>
              </div>
            )}

            <div className="mb-3 flex items-baseline justify-between">
              <span className="text-sm font-medium text-neutral-300">
                Total do Pedido
              </span>
              <div className="text-right">
                <span className="tabular-nums text-xl font-extrabold text-[#FFA000]">
                  {formatCurrency(numericSubtotal)}
                </span>
                {hasPriceOnRequest && (
                  <span className="block text-[11px] text-neutral-400">
                    + itens a consultar no WhatsApp
                  </span>
                )}
              </div>
            </div>

            <a
              href={whatsappUrl}
              target={isFormValid ? "_blank" : undefined}
              rel={isFormValid ? "noopener noreferrer" : undefined}
              onClick={handleCheckoutClick}
              className="flex min-h-[48px] w-full items-center justify-center gap-2 rounded-xl bg-[#FFA000] px-5 py-3 text-sm font-extrabold text-black transition-transform hover:brightness-105 active:scale-[0.98] sm:text-base"
            >
              <span>Finalizar Pedido no WhatsApp</span>
              <ExternalLink className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
            </a>
          </div>
        )}
      </div>
    </div>
  );
}
