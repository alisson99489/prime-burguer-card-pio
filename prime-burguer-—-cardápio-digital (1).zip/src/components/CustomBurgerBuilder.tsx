import { useMemo, useState } from "react";
import { Check, Minus, Plus, RotateCcw } from "lucide-react";
import { BUILDER_INGREDIENTS, formatCurrency } from "../data/menu";
import { AddonGroup } from "../types";

interface CustomBurgerBuilderProps {
  onAddCustomBurger: (
    ingredients: Array<{ name: string; price: number; quantity: number }>,
    totalPrice: number
  ) => void;
}

const GROUPS: AddonGroup[] = [
  "Base & Carnes",
  "Queijos",
  "Molhos",
  "Complementos",
];

export function CustomBurgerBuilder({
  onAddCustomBurger,
}: CustomBurgerBuilderProps) {
  const [quantities, setQuantities] = useState<Record<string, number>>({
    "ing-pao-brioche": 1,
    "ing-blend-150": 1,
  });
  const [addedFeedback, setAddedFeedback] = useState(false);

  const selectedList = useMemo(() => {
    return BUILDER_INGREDIENTS.filter((ing) => (quantities[ing.id] || 0) > 0).map(
      (ing) => ({
        ...ing,
        quantity: quantities[ing.id],
      })
    );
  }, [quantities]);

  const totalPrice = useMemo(() => {
    return selectedList.reduce(
      (sum, item) => sum + item.price * item.quantity,
      0
    );
  }, [selectedList]);

  const toggleIngredient = (id: string) => {
    setQuantities((prev) => {
      const current = prev[id] || 0;
      if (current > 0) {
        const next = { ...prev };
        delete next[id];
        return next;
      }
      return { ...prev, [id]: 1 };
    });
  };

  const adjustQuantity = (id: string, delta: number) => {
    setQuantities((prev) => {
      const nextQty = (prev[id] || 0) + delta;
      if (nextQty <= 0) {
        const next = { ...prev };
        delete next[id];
        return next;
      }
      return { ...prev, [id]: Math.min(nextQty, 5) };
    });
  };

  const handleReset = () => {
    setQuantities({});
  };

  const handleAdd = () => {
    if (selectedList.length === 0) return;
    onAddCustomBurger(
      selectedList.map((item) => ({
        name: item.name,
        price: item.price,
        quantity: item.quantity,
      })),
      totalPrice
    );
    setAddedFeedback(true);
    setTimeout(() => setAddedFeedback(false), 1600);
  };

  const customDescription = selectedList
    .map((i) => (i.quantity > 1 ? `${i.quantity}x ${i.name}` : i.name))
    .join(", ");

  return (
    <div className="rounded-xl border border-white/10 bg-[#1E1E1E] p-4 sm:p-6">
      <div className="flex flex-col gap-3 border-b border-white/10 pb-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h3 className="font-display text-xl font-bold tracking-tight text-white sm:text-2xl">
            Monte do Seu Jeito
          </h3>
          <p className="mt-0.5 text-xs text-neutral-400 sm:text-sm">
            Marque os ingredientes desejados e acompanhe o valor em tempo real.
          </p>
        </div>
        <div className="flex items-center gap-3 self-start sm:self-auto">
          {selectedList.length > 0 && (
            <button
              type="button"
              onClick={handleReset}
              className="inline-flex min-h-[40px] items-center gap-1.5 rounded-lg border border-white/10 px-3 py-1.5 text-xs font-medium text-neutral-300 transition-colors hover:bg-neutral-800 hover:text-white"
            >
              <RotateCcw className="h-3.5 w-3.5" aria-hidden="true" />
              <span>Limpar</span>
            </button>
          )}
          <div className="text-right">
            <span className="block text-[11px] font-medium text-neutral-400">
              Total do lanche
            </span>
            <span className="tabular-nums text-xl font-extrabold text-[#FFA000]">
              {formatCurrency(totalPrice)}
            </span>
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-5">
        {GROUPS.map((group) => {
          const groupItems = BUILDER_INGREDIENTS.filter(
            (item) => item.group === group
          );
          return (
            <div key={group}>
              <h4 className="mb-2.5 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                {group}
              </h4>
              <div className="grid grid-cols-1 gap-2 sm:grid-cols-2 lg:grid-cols-3">
                {groupItems.map((ingredient) => {
                  const qty = quantities[ingredient.id] || 0;
                  const isSelected = qty > 0;
                  return (
                    <div
                      key={ingredient.id}
                      className={`flex min-h-[48px] items-center justify-between gap-2 rounded-lg border px-3 py-2 transition-colors ${
                        isSelected
                          ? "border-[#FFA000] bg-[#FFA000]/10"
                          : "border-white/8 bg-[#121212] hover:border-white/20"
                      }`}
                    >
                      <button
                        type="button"
                        onClick={() => toggleIngredient(ingredient.id)}
                        className="flex min-h-[36px] flex-1 items-center gap-2.5 text-left"
                      >
                        <span
                          className={`flex h-5 w-5 shrink-0 items-center justify-center rounded border transition-colors ${
                            isSelected
                              ? "border-[#FFA000] bg-[#FFA000] text-black"
                              : "border-neutral-600 bg-transparent"
                          }`}
                        >
                          {isSelected && (
                            <Check className="h-3.5 w-3.5 stroke-[3]" aria-hidden="true" />
                          )}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-medium text-white">
                            {ingredient.name}
                          </span>
                          <span className="tabular-nums block text-xs font-semibold text-[#FFA000]">
                            + {formatCurrency(ingredient.price)}
                          </span>
                        </span>
                      </button>

                      {isSelected && (
                        <div className="flex shrink-0 items-center gap-1 rounded-md bg-[#1E1E1E] p-0.5">
                          <button
                            type="button"
                            onClick={() => adjustQuantity(ingredient.id, -1)}
                            aria-label={`Diminuir ${ingredient.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded text-neutral-300 hover:bg-neutral-800 hover:text-white"
                          >
                            <Minus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                          <span className="tabular-nums min-w-[1.25rem] text-center text-xs font-bold text-white">
                            {qty}
                          </span>
                          <button
                            type="button"
                            onClick={() => adjustQuantity(ingredient.id, 1)}
                            aria-label={`Aumentar ${ingredient.name}`}
                            className="flex h-8 w-8 items-center justify-center rounded text-[#FFA000] hover:bg-neutral-800"
                          >
                            <Plus className="h-3.5 w-3.5" aria-hidden="true" />
                          </button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-5 flex flex-col gap-2.5 border-t border-white/10 pt-4 sm:flex-row sm:items-center sm:justify-between">
        <div className="min-w-0 text-xs text-neutral-300">
          {selectedList.length > 0 ? (
            <p className="line-clamp-2">
              <span className="font-semibold text-white">Selecionados: </span>
              {customDescription}
            </p>
          ) : (
            <p className="text-neutral-400">
              Selecione ao menos 1 ingrediente para montar seu burguer.
            </p>
          )}
        </div>

        <div className="flex shrink-0 flex-wrap items-center gap-2">
          <button
            type="button"
            disabled={selectedList.length === 0}
            onClick={handleAdd}
            className="inline-flex min-h-[44px] flex-1 items-center justify-center gap-2 rounded-lg bg-[#FFA000] px-5 py-2.5 text-sm font-bold text-black transition-all hover:brightness-105 active:scale-[0.98] disabled:cursor-not-allowed disabled:opacity-40 sm:flex-initial whitespace-nowrap"
          >
            {addedFeedback ? (
              <>
                <Check className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
                <span>Adicionado!</span>
              </>
            ) : (
              <>
                <Plus className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
                <span>Adicionar ({formatCurrency(totalPrice)})</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
