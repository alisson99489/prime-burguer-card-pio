import { useState } from "react";
import { Clock, MapPin } from "lucide-react";
import { STORE_INFO } from "../data/menu";

export function Header() {
  const [logoError, setLogoError] = useState(false);

  return (
    <header className="border-b border-white/10 bg-[#121212]">
      <div className="mx-auto flex max-w-6xl items-center justify-between gap-4 px-4 py-4 sm:px-6 sm:py-5">
        <div className="flex items-center gap-3.5 sm:gap-4 min-w-0">
          <div className="relative h-14 w-14 shrink-0 overflow-hidden rounded-full bg-[#FFA000] ring-2 ring-[#FFA000]/30 sm:h-16 sm:w-16">
            {!logoError ? (
              <img
                src={STORE_INFO.logoPath}
                alt="Logotipo oficial Prime Burguer"
                referrerPolicy="no-referrer"
                onError={() => setLogoError(true)}
                className="h-full w-full scale-[1.82] object-cover object-center select-none"
              />
            ) : (
              <div className="flex h-full w-full items-center justify-center text-center font-display text-sm font-extrabold leading-none tracking-tight text-black">
                PRIME
                <br />
                BURGUER
              </div>
            )}
          </div>

          <div className="min-w-0">
            <h1 className="font-display text-2xl font-extrabold tracking-tight text-white sm:text-3xl">
              Prime Burguer
            </h1>
            <div className="mt-0.5 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-xs text-neutral-300 sm:text-sm">
              <span className="inline-flex items-center gap-1">
                <MapPin className="h-3.5 w-3.5 shrink-0 text-[#FFA000]" aria-hidden="true" />
                <span>{STORE_INFO.location}</span>
              </span>
              <span className="hidden text-neutral-600 sm:inline" aria-hidden="true">
                ·
              </span>
              <span className="inline-flex items-center gap-1 text-neutral-400">
                <Clock className="h-3.5 w-3.5 shrink-0 text-[#FFA000]" aria-hidden="true" />
                <span>{STORE_INFO.hours}</span>
              </span>
            </div>
          </div>
        </div>

        <a
          href="#monte-seu-burguer"
          className="hidden min-h-[44px] shrink-0 items-center justify-center rounded-lg bg-[#FFA000] px-4 py-2 text-sm font-bold text-black transition-transform hover:brightness-105 active:scale-[0.98] sm:inline-flex whitespace-nowrap"
        >
          Monte seu Burguer
        </a>
      </div>
    </header>
  );
}
