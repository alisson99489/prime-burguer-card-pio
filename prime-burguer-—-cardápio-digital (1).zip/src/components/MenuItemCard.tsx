import { Minus, Plus } from "lucide-react";
import { formatCurrency } from "../data/menu";
import { MenuItem } from "../types";

interface MenuItemCardProps {
  item: MenuItem;
  quantityInCart: number;
  onAdd: (item: MenuItem) => void;
  onIncrement?: (item: MenuItem) => void;
  onDecrement?: (item: MenuItem) => void;
}

export function MenuItemCard({
  item,
  quantityInCart,
  onAdd,
  onIncrement,
  onDecrement,
}: MenuItemCardProps) {
  const isCustomizable = Boolean(item.customizationType);

  return (
    <article className="flex flex-col justify-between gap-3 rounded-xl border border-white/8 bg-[#1E1E1E] p-4 transition-colors hover:border-white/15">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0 flex-1">
          <div className="flex items-baseline gap-2">
            <h3 className="text-base font-semibold leading-snug text-white">
              {item.name}
            </h3>
            {item.highlightNote && (
              <span className="text-xs font-medium text-neutral-400">
                · {item.highlightNote}
              </span>
            )}
          </div>
          {item.description && (
            <p className="mt-1 text-xs leading-relaxed text-neutral-400 sm:text-[13px]">
              {item.description}
            </p>
          )}
        </div>

        <div className="shrink-0 text-right">
          {item.priceOnRequest || item.price === null ? (
            <span className="text-xs font-semibold text-[#FFA000] sm:text-sm">
              Consultar valor
            </span>
          ) : (
            <span className="tabular-nums text-base font-bold text-[#FFA000]">
              {formatCurrency(item.price)}
            </span>
          )}
        </div>
      </div>

      <div className="flex items-center justify-between gap-2 pt-1">
        {isCustomizable && quantityInCart > 0 ? (
          <span className="tabular-nums text-xs font-medium text-neutral-300">
            {quantityInCart} {quantityInCart === 1 ? "no pedido" : "no pedido"}
          </span>
        ) : (
          <span />
        )}

        {!isCustomizable && quantityInCart > 0 ? (
          <div className="inline-flex items-center overflow-hidden rounded-lg border border-[#FFA000]/40 bg-[#121212]">
            <button
              type="button"
              onClick={() => onDecrement?.(item)}
              aria-label={`Remover uma unidade de ${item.name}`}
              className="flex min-h-[44px] min-w-[44px] items-center justify-center text-white transition-colors hover:bg-neutral-800 active:bg-neutral-700"
            >
              <Minus className="h-4 w-4" aria-hidden="true" />
            </button>
            <span className="tabular-nums min-w-[2.25rem] text-center text-sm font-bold text-white">
              {quantityInCart}
            </span>
            <button
              type="button"
              onClick={() => onIncrement?.(item)}
              aria-label={`Adicionar mais uma unidade de ${item.name}`}
              className="flex min-h-[44px] min-w-[44px] items-center justify-center bg-[#FFA000] text-black transition-colors hover:brightness-105 active:scale-95"
            >
              <Plus className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
            </button>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => onAdd(item)}
            className="inline-flex min-h-[44px] shrink-0 items-center justify-center gap-1.5 rounded-lg bg-[#FFA000] px-4 py-2 text-sm font-bold text-black transition-transform hover:brightness-105 active:scale-[0.98] whitespace-nowrap"
          >
            <Plus className="h-4 w-4 stroke-[2.5]" aria-hidden="true" />
            <span>
              {isCustomizable && quantityInCart > 0 ? "Escolher outro" : "Adicionar"}
            </span>
          </button>
        )}
      </div>
    </article>
  );
}
