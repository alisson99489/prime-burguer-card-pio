import { useState } from "react";
import { Check, X } from "lucide-react";
import {
  JUICE_FLAVORS,
  JUICE_MILK_SURCHARGE,
  SODA_FLAVORS,
  formatCurrency,
} from "../data/menu";
import { JuiceFlavor, MenuItem, SodaFlavor } from "../types";

interface OptionModalProps {
  item: MenuItem;
  onClose: () => void;
  onConfirm: (
    item: MenuItem,
    details: string[],
    finalUnitPrice: number,
    variantKey: string
  ) => void;
}

export function OptionModal({ item, onClose, onConfirm }: OptionModalProps) {
  const isJuice = item.customizationType === "juice";
  const sodaCount = item.sodaSlots ?? 1;

  const [selectedJuice, setSelectedJuice] = useState<JuiceFlavor>(
    JUICE_FLAVORS[0]
  );
  const [withMilk, setWithMilk] = useState(false);

  const [selectedSodas, setSelectedSodas] = useState<SodaFlavor[]>(() =>
    Array.from({ length: sodaCount }, () => SODA_FLAVORS[0])
  );

  const basePrice = item.price ?? 0;
  const finalPrice = isJuice
    ? basePrice + (withMilk ? JUICE_MILK_SURCHARGE : 0)
    : basePrice;

  const handleSodaChange = (slotIndex: number, flavor: SodaFlavor) => {
    setSelectedSodas((prev) => {
      const next = [...prev];
      next[slotIndex] = flavor;
      return next;
    });
  };

  const handleConfirm = () => {
    if (isJuice) {
      const details = [
        `Sabor: ${selectedJuice}`,
        withMilk ? "Com leite (+R$ 3,00)" : "Sem leite",
      ];
      const variantKey = `juice-${selectedJuice}-${withMilk ? "leite" : "agua"}`;
      onConfirm(item, details, finalPrice, variantKey);
      return;
    }

    const sizeLabel = item.sodaSize === "1L" ? "Refri 1L" : "Refri Lata";
    const details =
      sodaCount === 1
        ? [`${sizeLabel}: ${selectedSodas[0]}`]
        : selectedSodas.map((s, idx) => `${sizeLabel} ${idx + 1}: ${s}`);
    const variantKey = `soda-${selectedSodas.join("-")}`;
    onConfirm(item, details, finalPrice, variantKey);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-black/70 backdrop-blur-xs sm:items-center sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="option-modal-title"
    >
      <div className="w-full max-w-md rounded-t-2xl border border-white/10 bg-[#1E1E1E] p-5 shadow-2xl sm:rounded-2xl">
        <div className="flex items-start justify-between gap-3 border-b border-white/10 pb-3">
          <div>
            <h3
              id="option-modal-title"
              className="font-display text-xl font-bold text-white"
            >
              {item.name}
            </h3>
            {item.description && (
              <p className="mt-0.5 text-xs text-neutral-400">
                {item.description}
              </p>
            )}
          </div>
          <button
            type="button"
            onClick={onClose}
            aria-label="Fechar seleção"
            className="flex min-h-[44px] min-w-[44px] items-center justify-center rounded-lg text-neutral-400 transition-colors hover:bg-neutral-800 hover:text-white"
          >
            <X className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>

        <div className="mt-4 space-y-4">
          {isJuice ? (
            <>
              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Escolha o sabor do suco
                </p>
                <div className="grid grid-cols-2 gap-2">
                  {JUICE_FLAVORS.map((flavor) => {
                    const active = selectedJuice === flavor;
                    return (
                      <button
                        key={flavor}
                        type="button"
                        onClick={() => setSelectedJuice(flavor)}
                        className={`flex min-h-[44px] items-center justify-between rounded-lg border px-3 py-2 text-sm font-medium transition-colors ${
                          active
                            ? "border-[#FFA000] bg-[#FFA000]/15 text-white"
                            : "border-white/10 bg-[#121212] text-neutral-300 hover:border-white/25"
                        }`}
                      >
                        <span>{flavor}</span>
                        {active && (
                          <Check
                            className="h-4 w-4 text-[#FFA000]"
                            aria-hidden="true"
                          />
                        )}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div>
                <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                  Adicional opcional
                </p>
                <button
                  type="button"
                  onClick={() => setWithMilk((prev) => !prev)}
                  className={`flex min-h-[48px] w-full items-center justify-between rounded-lg border px-3.5 py-2.5 text-left transition-colors ${
                    withMilk
                      ? "border-[#FFA000] bg-[#FFA000]/15"
                      : "border-white/10 bg-[#121212] hover:border-white/25"
                  }`}
                >
                  <div>
                    <span className="block text-sm font-semibold text-white">
                      Com leite
                    </span>
                    <span className="tabular-nums text-xs text-[#FFA000]">
                      + {formatCurrency(JUICE_MILK_SURCHARGE)}
                    </span>
                  </div>
                  <span
                    className={`flex h-6 w-6 items-center justify-center rounded border ${
                      withMilk
                        ? "border-[#FFA000] bg-[#FFA000] text-black"
                        : "border-neutral-600"
                    }`}
                  >
                    {withMilk && (
                      <Check className="h-4 w-4 stroke-[3]" aria-hidden="true" />
                    )}
                  </span>
                </button>
              </div>
            </>
          ) : (
            <div className="space-y-4">
              {selectedSodas.map((chosenFlavor, slotIdx) => (
                <div key={slotIdx}>
                  <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-neutral-400">
                    {sodaCount > 1
                      ? `Escolha o Refrigerante ${slotIdx + 1}`
                      : `Escolha o sabor (${item.sodaSize === "1L" ? "Refri 1L" : "Refri Lata"})`}
                  </p>
                  <div className="grid grid-cols-3 gap-2">
                    {SODA_FLAVORS.map((flavor) => {
                      const active = chosenFlavor === flavor;
                      return (
                        <button
                          key={flavor}
                          type="button"
                          onClick={() => handleSodaChange(slotIdx, flavor)}
                          className={`flex min-h-[44px] items-center justify-center rounded-lg border px-2 py-2 text-xs font-semibold transition-colors sm:text-sm ${
                            active
                              ? "border-[#FFA000] bg-[#FFA000] font-bold text-black"
                              : "border-white/10 bg-[#121212] text-neutral-300 hover:border-white/25"
                          }`}
                        >
                          {flavor}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="mt-6 flex items-center justify-between gap-3 border-t border-white/10 pt-4">
          <div>
            <span className="block text-[11px] text-neutral-400">Valor</span>
            <span className="tabular-nums text-lg font-extrabold text-[#FFA000]">
              {formatCurrency(finalPrice)}
            </span>
          </div>

          <button
            type="button"
            onClick={handleConfirm}
            className="min-h-[46px] flex-1 rounded-lg bg-[#FFA000] px-5 py-2.5 text-sm font-bold text-black transition-transform hover:brightness-105 active:scale-[0.98]"
          >
            Confirmar e Adicionar
          </button>
        </div>
      </div>
    </div>
  );
}
