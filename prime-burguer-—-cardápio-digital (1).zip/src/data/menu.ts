import {
  BuilderIngredient,
  CartItem,
  CategoryId,
  CheckoutInfo,
  JuiceFlavor,
  MenuItem,
  SodaFlavor,
} from "../types";

export const STORE_INFO = {
  name: "Prime Burguer",
  location: "Projeto NH3 • Esquina da Rua 06",
  hours: "Quarta a Segunda, das 18h às 23h",
  whatsappNumber: "557481414076",
  logoPath:
    "/assets/aistudio/Screenshot_2026-11-12-22-07-12-939_com.instagram.android_da8d1abc.jpg",
} as const;

export const CATEGORY_TABS: { id: CategoryId; label: string }[] = [
  { id: "hamburgueres", label: "Hambúrgueres" },
  { id: "combos", label: "Combos" },
  { id: "monte-seu-burguer", label: "Monte seu Burguer" },
  { id: "porcoes", label: "Porções" },
  { id: "bebidas", label: "Bebidas" },
];

export const JUICE_FLAVORS: JuiceFlavor[] = [
  "Maracujá",
  "Acerola",
  "Goiaba",
  "Cacau",
  "Cupuaçu",
];

export const JUICE_MILK_SURCHARGE = 3;

export const SODA_FLAVORS: SodaFlavor[] = ["Coca-Cola", "Guaraná", "Fanta"];

export const MENU_ITEMS: MenuItem[] = [
  // HAMBÚRGUERES (Todos acompanham molho verde)
  {
    id: "burger-simplao",
    category: "hamburgueres",
    name: "Simplão",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, alface e tomate.",
    price: 22,
  },
  {
    id: "burger-salad",
    category: "hamburgueres",
    name: "Salad",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, cebola roxa, alface, tomate, picles e molho verde.",
    price: 28,
  },
  {
    id: "burger-bacon",
    category: "hamburgueres",
    name: "Bacon",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo cheddar, tiras de bacon, cebola caramelizada e molho cheddar.",
    price: 32,
  },
  {
    id: "burger-duplo-bacon",
    category: "hamburgueres",
    name: "Duplo Bacon",
    description:
      "Pão brioche selado na manteiga, 2x blend bovino 150g, 2x queijo cheddar, 2x bacon, 2x molho cheddar e 2x cebola caramelizada.",
    price: 45,
  },
  {
    id: "burger-catupiry",
    category: "hamburgueres",
    name: "Catupiry",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela, catupiry original, cebola caramelizada e picles.",
    price: 29,
  },
  {
    id: "burger-catupiry-crocante",
    category: "hamburgueres",
    name: "Catupiry Crocante",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, empanado de catupiry crocante e bacon.",
    price: 36,
  },
  {
    id: "burger-tentacao",
    category: "hamburgueres",
    name: "Tentação",
    description:
      "Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, carne de sol desfiada, fatia de queijo coalho e molho barbecue.",
    price: 35,
  },

  // COMBOS
  {
    id: "combo-01",
    category: "combos",
    name: "Combo 01",
    description: "2 Simplão, 2 batatas 100g e 2 refri lata.",
    price: 56,
    customizationType: "soda",
    sodaSlots: 2,
    sodaSize: "Lata",
  },
  {
    id: "combo-02",
    category: "combos",
    name: "Combo 02",
    description: "1 Bacon, 1 batata de 100g e 1 refri lata.",
    price: 38,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "Lata",
  },
  {
    id: "combo-03",
    category: "combos",
    name: "Combo 03",
    description: "1 Duplo, 1 batata de 100g e 1 refri lata.",
    price: 51,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "Lata",
  },
  {
    id: "combo-04",
    category: "combos",
    name: "Combo 04",
    description: "1 Catupiry, 1 batata de 100g e 1 refri lata.",
    price: 35,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "Lata",
  },
  {
    id: "combo-05",
    category: "combos",
    name: "Combo 05",
    description: "2 Bacon, 2 batata 100g e 2 refri lata.",
    price: 76,
    customizationType: "soda",
    sodaSlots: 2,
    sodaSize: "Lata",
  },
  {
    id: "combo-06",
    category: "combos",
    name: "Combo 06",
    description:
      "2 Brasa Bacon, batata com cheddar e bacon de 200g, 10 mini coxinha, 10 anéis de cebola e 1 Refri de 1L.",
    price: 110,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "1L",
  },
  {
    id: "combo-07",
    category: "combos",
    name: "Combo 07",
    description: "3 Brasa Bacon, 3 batatas de 100g e 1 refri de 1L.",
    price: 115,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "1L",
  },

  // PORÇÕES & SOBREMESA
  {
    id: "porcao-batata-simples",
    category: "porcoes",
    name: "Batata simples",
    description: "Porção crocante de batata frita sequinha.",
    price: 17,
  },
  {
    id: "porcao-batata-bacon-cheddar",
    category: "porcoes",
    name: "Batata com bacon e cheddar",
    description: "Batata frita coberta com cheddar cremoso e cubos de bacon.",
    price: 25,
  },
  {
    id: "porcao-batata-carne-seca",
    category: "porcoes",
    name: "Batata com carne seca e catupiry",
    description: "Batata frita com carne seca desfiada e catupiry original.",
    price: 30,
  },
  {
    id: "porcao-minis-coxinhas",
    category: "porcoes",
    name: "Minis coxinhas (10U)",
    description: "10 unidades de mini coxinhas douradas e crocantes.",
    price: 22,
  },
  {
    id: "porcao-minis-pasteis",
    category: "porcoes",
    name: "Minis pastéis (10U)",
    description: "10 unidades de mini pastéis fritos na hora.",
    price: 22,
  },
  {
    id: "porcao-croquete-cupim",
    category: "porcoes",
    name: "Croquete de cupim com catupiry",
    description: "Croquetes artesanais de cupim recheados com catupiry.",
    price: 25,
  },
  {
    id: "sobremesa-mini-pudim",
    category: "porcoes",
    name: "Mini pudim de sobremesa",
    description: "Consulte o valor do dia ao finalizar seu pedido no WhatsApp.",
    price: null,
    priceOnRequest: true,
    highlightNote: "Sobremesa",
  },

  // BEBIDAS
  {
    id: "bebida-agua-mineral",
    category: "bebidas",
    name: "Água mineral",
    description: "Garrafa sem gás bem gelada.",
    price: 3,
  },
  {
    id: "bebida-agua-gas",
    category: "bebidas",
    name: "Água com gás",
    description: "Garrafa com gás bem gelada.",
    price: 4,
  },
  {
    id: "bebida-refri-lata",
    category: "bebidas",
    name: "Refrigerante Lata",
    description: "Escolha o sabor: Coca-Cola, Guaraná ou Fanta.",
    price: 6,
    customizationType: "soda",
    sodaSlots: 1,
    sodaSize: "Lata",
  },
  {
    id: "bebida-coca-1l",
    category: "bebidas",
    name: "Coca-Cola 1L",
    description: "Garrafa 1 litro gelada.",
    price: 12,
  },
  {
    id: "bebida-guarana-1l",
    category: "bebidas",
    name: "Guaraná 1L",
    description: "Garrafa 1 litro gelada.",
    price: 10,
  },
  {
    id: "bebida-suco-500",
    category: "bebidas",
    name: "Suco 500 ml",
    description:
      "Sabores: Maracujá, Acerola, Goiaba, Cacau ou Cupuaçu. Opção com leite (+R$ 3,00).",
    price: 8,
    customizationType: "juice",
  },
  {
    id: "bebida-suco-1l",
    category: "bebidas",
    name: "Suco 1L",
    description:
      "Sabores: Maracujá, Acerola, Goiaba, Cacau ou Cupuaçu. Opção com leite (+R$ 3,00).",
    price: 14,
    customizationType: "juice",
  },
];

export const BUILDER_INGREDIENTS: BuilderIngredient[] = [
  { id: "ing-pao-brioche", name: "Pão brioche", price: 4, group: "Base & Carnes" },
  { id: "ing-blend-150", name: "Blend 150g", price: 12, group: "Base & Carnes" },
  { id: "ing-bacon", name: "Bacon", price: 5, group: "Base & Carnes" },
  { id: "ing-calabresa", name: "Calabresa", price: 4, group: "Base & Carnes" },
  { id: "ing-ovo", name: "Ovo", price: 3, group: "Base & Carnes" },

  { id: "ing-catupiry", name: "Catupiry original", price: 6, group: "Queijos" },
  { id: "ing-cheddar", name: "Queijo cheddar", price: 2, group: "Queijos" },
  { id: "ing-mussarela", name: "Queijo mussarela", price: 2, group: "Queijos" },
  { id: "ing-coalho", name: "Queijo coalho", price: 4, group: "Queijos" },

  { id: "ing-molho-cheddar", name: "Molho cheddar", price: 5, group: "Molhos" },
  { id: "ing-molho-barbecue", name: "Molho barbecue", price: 3, group: "Molhos" },
  { id: "ing-molho-baconese", name: "Molho baconese", price: 4, group: "Molhos" },
  { id: "ing-molho-verde", name: "Molho verde", price: 4, group: "Molhos" },

  { id: "ing-alface", name: "Alface", price: 2, group: "Complementos" },
  { id: "ing-tomate", name: "Tomate", price: 2, group: "Complementos" },
  { id: "ing-cebola-roxa", name: "Cebola roxa", price: 2, group: "Complementos" },
  { id: "ing-picles", name: "Picles", price: 3, group: "Complementos" },
  {
    id: "ing-cebola-caramelizada",
    name: "Cebola caramelizada",
    price: 3,
    group: "Complementos",
  },
  { id: "ing-aneis-cebola", name: "Anéis de cebola", price: 5, group: "Complementos" },
];

export function formatCurrency(value: number): string {
  return value.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
  });
}

export function buildWhatsAppOrderText(
  items: CartItem[],
  checkout: CheckoutInfo
): string {
  const lines: string[] = [];
  lines.push("*NOVO PEDIDO — PRIME BURGUER*");
  lines.push("--------------------------------");
  lines.push("");
  lines.push("*ITENS DO PEDIDO:*");

  let numericSubtotal = 0;
  let hasPriceOnRequest = false;

  items.forEach((item, idx) => {
    if (item.priceOnRequest || item.unitPrice === null) {
      hasPriceOnRequest = true;
      lines.push(`${idx + 1}. ${item.quantity}x ${item.name} — _A consultar_`);
    } else {
      const lineTotal = item.unitPrice * item.quantity;
      numericSubtotal += lineTotal;
      lines.push(
        `${idx + 1}. ${item.quantity}x ${item.name} — ${formatCurrency(lineTotal)}`
      );
    }

    if (item.details && item.details.length > 0) {
      item.details.forEach((detail) => {
        lines.push(`   • ${detail}`);
      });
    }
  });

  lines.push("");
  lines.push("--------------------------------");
  lines.push("*DADOS DO CLIENTE:*");
  lines.push(`• Nome: ${checkout.customerName.trim()}`);
  lines.push(
    `• Entrega: ${
      checkout.deliveryType === "entrega"
        ? "Entrega (Taxa a combinar no WhatsApp)"
        : "Retirada no local"
    }`
  );
  if (checkout.deliveryType === "entrega") {
    lines.push(`• Endereço: ${checkout.address.trim()}`);
  }
  lines.push(`• Pagamento: ${checkout.paymentMethod}`);
  if (checkout.paymentMethod === "Dinheiro") {
    const changeText = checkout.changeFor.trim()
      ? checkout.changeFor.trim()
      : "Não precisa de troco";
    lines.push(`• Troco para: ${changeText}`);
  }
  if (checkout.notes.trim()) {
    lines.push(`• Observações: ${checkout.notes.trim()}`);
  }

  lines.push("");
  lines.push("--------------------------------");
  const totalLabel = hasPriceOnRequest
    ? `${formatCurrency(numericSubtotal)} (+ itens a consultar)`
    : formatCurrency(numericSubtotal);
  lines.push(`*TOTAL:* ${totalLabel}`);

  return lines.join("\n");
}

export function buildWhatsAppUrl(
  items: CartItem[],
  checkout: CheckoutInfo
): string {
  const message = buildWhatsAppOrderText(items, checkout);
  return `https://wa.me/${STORE_INFO.whatsappNumber}?text=${encodeURIComponent(
    message
  )}`;
}

export const MENU_CONTEXT_FOR_AI = `
Você é o Atendente Digital da hamburgueria "Prime Burguer".
Localização: Projeto NH3 • Esquina da Rua 06.
Horário de funcionamento: Quarta a Segunda, das 18h às 23h (fechado às terças).
WhatsApp para pedidos: +55 74 8141-4076.

CARDÁPIO OFICIAL:
HAMBÚRGUERES (Obs: todos os hambúrgueres acompanham molho verde):
- Simplão (R$ 22,00): Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, alface e tomate.
- Salad (R$ 28,00): Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, cebola roxa, alface, tomate, picles e molho verde.
- Bacon (R$ 32,00): Pão brioche selado na manteiga, blend bovino 150g, queijo cheddar, tiras de bacon, cebola caramelizada e molho cheddar.
- Duplo Bacon (R$ 45,00): Pão brioche selado na manteiga, 2x blend bovino 150g, 2x queijo cheddar, 2x bacon, 2x molho cheddar e 2x cebola caramelizada.
- Catupiry (R$ 29,00): Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela, catupiry original, cebola caramelizada e picles.
- Catupiry Crocante (R$ 36,00): Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, empanado de catupiry crocante e bacon.
- Tentação (R$ 35,00): Pão brioche selado na manteiga, blend bovino 150g, queijo mussarela derretido, carne de sol desfiada, fatia de queijo coalho e molho barbecue.

COMBOS (Refrigerantes disponíveis: Coca-Cola, Guaraná, Fanta):
- Combo 01 (R$ 56,00): 2 Simplão, 2 batatas 100g e 2 refri lata.
- Combo 02 (R$ 38,00): 1 Bacon, 1 batata de 100g e 1 refri lata.
- Combo 03 (R$ 51,00): 1 Duplo, 1 batata de 100g e 1 refri lata.
- Combo 04 (R$ 35,00): 1 Catupiry, 1 batata de 100g e 1 refri lata.
- Combo 05 (R$ 76,00): 2 Bacon, 2 batata 100g e 2 refri lata.
- Combo 06 (R$ 110,00): 2 Brasa Bacon, batata com cheddar e bacon de 200g, 10 mini coxinha, 10 anéis de cebola e 1 Refri de 1L.
- Combo 07 (R$ 115,00): 3 Brasa Bacon, 3 batatas de 100g e 1 refri de 1L.

MONTE SEU BURGUER (Adicionais):
- Pão brioche (R$ 4), Blend 150g (R$ 12), Bacon (R$ 5), Calabresa (R$ 4), Molho cheddar (R$ 5), Molho barbecue (R$ 3), Molho baconese (R$ 4), Molho verde (R$ 4), Catupiry original (R$ 6), Queijo cheddar (R$ 2), Queijo mussarela (R$ 2), Queijo coalho (R$ 4), Ovo (R$ 3), Alface (R$ 2), Tomate (R$ 2), Cebola roxa (R$ 2), Picles (R$ 3), Cebola caramelizada (R$ 3), Anéis de cebola (R$ 5).

PORÇÕES & SOBREMESA:
- Batata simples (R$ 17), Batata com bacon e cheddar (R$ 25), Batata com carne seca e catupiry (R$ 30), Minis coxinhas 10U (R$ 22), Minis pastéis 10U (R$ 22), Croquete de cupim com catupiry (R$ 25), Mini pudim de sobremesa (Consultar valor no WhatsApp).

BEBIDAS:
- Água mineral (R$ 3), Água com gás (R$ 4), Refrigerante Lata (R$ 6 - Coca-Cola, Guaraná, Fanta), Coca-Cola 1L (R$ 12), Guaraná 1L (R$ 10), Suco 500 ml (R$ 8), Suco 1L (R$ 14).
- Sabores de suco: Maracujá, Acerola, Goiaba, Cacau, Cupuaçu. Adicional com leite: +R$ 3,00.

REGRAS DE ATENDIMENTO:
- Responda sempre em português brasileiro, de forma amigável, concisa e objetiva (ideal para leitura rápida no celular).
- Informe que a taxa de entrega é combinada diretamente no WhatsApp ao finalizar o pedido.
- Nunca invente preços ou itens que não estejam no cardápio acima.
`;
