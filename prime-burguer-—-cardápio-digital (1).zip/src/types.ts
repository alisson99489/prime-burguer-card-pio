export type CategoryId =
  | "hamburgueres"
  | "combos"
  | "monte-seu-burguer"
  | "porcoes"
  | "bebidas";

export type CustomizationType = "juice" | "soda";

export interface MenuItem {
  id: string;
  category: CategoryId;
  name: string;
  description?: string;
  price: number | null; // null when "Consultar valor"
  priceOnRequest?: boolean;
  customizationType?: CustomizationType;
  sodaSlots?: number;
  sodaSize?: "Lata" | "1L";
  highlightNote?: string;
}

export type AddonGroup =
  | "Base & Carnes"
  | "Queijos"
  | "Molhos"
  | "Complementos";

export interface BuilderIngredient {
  id: string;
  name: string;
  price: number;
  group: AddonGroup;
}

export type JuiceFlavor =
  | "Maracujá"
  | "Acerola"
  | "Goiaba"
  | "Cacau"
  | "Cupuaçu";

export type SodaFlavor = "Coca-Cola" | "Guaraná" | "Fanta";

export interface CartItem {
  cartKey: string;
  itemId: string;
  name: string;
  unitPrice: number | null;
  priceOnRequest?: boolean;
  quantity: number;
  details?: string[];
}

export type DeliveryType = "retirada" | "entrega";
export type PaymentMethod = "Pix" | "Cartão" | "Dinheiro";

export interface CheckoutInfo {
  customerName: string;
  deliveryType: DeliveryType;
  address: string;
  paymentMethod: PaymentMethod;
  changeFor: string;
  notes: string;
}

export interface ChatMessage {
  id: string;
  role: "user" | "model";
  text: string;
}

export type ImageResolution = "1K" | "2K" | "4K";
